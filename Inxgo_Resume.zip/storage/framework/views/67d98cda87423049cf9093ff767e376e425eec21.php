

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 4.5rem!important;">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header"><h5>Hello, <?php echo e(ucwords(Auth::user()->name)); ?></h5></div>
                <div class="card-body">
                    <h3 class="text-info" style="display:inline-block">Your Work Summery</h3>
                    <div class="text-right" style="display:inline-block;float:right">
                        <a href="<?php echo e(route('work_create')); ?>" class="btn btn-outline-success">Add More</a>
                    </div>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">SL</th>
                                <th scope="col">Company Name</th>
                                <th scope="col">Position</th>
                                <th scope="col">Year</th>
                                <th scope="col">Actons</th>
                            </tr>
                        </thead>
                      <tbody>
                          <?php
                          $i=1
                          ?>
                           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td><?php echo e($d->company_name); ?></td>
                                <td><?php echo e($d->position); ?></td>
                                <td><?php echo e($d->year); ?></td>
                                <td>
                                    <a href="<?php echo e(url('work_update/'.base64_encode($d->id))); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(url('work_delete/'.base64_encode($d->id))); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure ?')">Delete</a>
                                   
                                </td>
                               
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5">
                                    <a href="<?php echo e(route('certificate_create')); ?>" class="btn btn-block btn-success">Continue Next</a>
                                </td>
                            </tr>
                             <tr>
                                <td colspan="5">
                                    <a href="<?php echo e(route('education_index')); ?>" class="btn btn-block btn-primary">Back to Education Summery</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-3 align-self-center">
            <h5 class="text-info">This is a Demo Resume.</h5>
            <img src="<?php echo e(asset('images/cv.jpg')); ?>" alt="" class="img-fluid">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\shahbaz\Inxgo_Resume\resources\views/work/index.blade.php ENDPATH**/ ?>