<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" style="overflow-x: hidden !important;">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title> <?php echo $__env->yieldContent('title','inXgo Resume'); ?></title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/dzsparallaxer.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/form-script.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/jquery.syotimer.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/plugins.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/script.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/about-sonar.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/animated-headline.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/classy-nav.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/dzsparallaxer.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/magnific-popup.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/owl.carousel.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/themify-icons.css')); ?>" rel="stylesheet">

    </head>
    <body class="light-version">
<header class="header-area">
        <div class="classy-nav-container dark breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="dreamNav">
                    <!-- Logo -->
                    <a class="nav-brand" href="<?php echo e(url('/')); ?>"><img src="img/core-img/logo.png" alt="logo"></a>
                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler"> <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>
                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- close btn -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li><a href="index.html">Home</a></li>
                                <!--<li><a href="about-us.html">About Us</a></li>
                                <li><a href="pricing.html">Pricing</a></li>
                                <li><a href="templates.html">Templates</a></li>
                                <li><a href="contact-us.html">Contact</a></li>-->
                                 <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Basic Info</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('education_summery') ? 'active' : ''); ?> <?php echo e(request()->is('education_information') ? 'active' : ''); ?>" href="<?php echo e(route('education_create')); ?>">Education</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('work_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('work_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('work_create')); ?>">Work</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('certificate_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('certificate_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('certificate_create')); ?>">Cetrifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('ca_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('ca_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('ca_create')); ?>">Career Object</a>
                            </li>

                            </ul>
                           
                        <ul class="nav">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link btn login-btn mr-im" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link btn login-btn mr-im" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="dropdown-backdrop" href="<?php echo e(route('logout')); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </nav>
            </div>
        </div>

    </header>
        <div id="app">
            <!--<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        Resume.io
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        Left Side Of Navbar -->
                        <!--<ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Basic Info</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('education_summery') ? 'active' : ''); ?> <?php echo e(request()->is('education_information') ? 'active' : ''); ?>" href="<?php echo e(route('education_create')); ?>">Education</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('work_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('work_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('work_create')); ?>">Work</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('certificate_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('certificate_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('certificate_create')); ?>">Cetrifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('ca_information_create') ? 'active' : ''); ?> <?php echo e(request()->is('ca_summery_display') ? 'active' : ''); ?>" href="<?php echo e(route('ca_create')); ?>">Career Object</a>
                            </li>
                        </ul>-->

                        <!-- Right Side Of Navbar -->
                        <!--<ul class="navbar-nav ml-auto">
                          
                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>-->
                    </div>
                </div>
            </nav>
            <div class="container mt-2">
                <?php if(session('update')): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('update')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <?php if(session('delete')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('delete')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </body>
</html>
<?php /**PATH D:\shahbaz\Inxgo_Resume\resources\views/layouts/app.blade.php ENDPATH**/ ?>